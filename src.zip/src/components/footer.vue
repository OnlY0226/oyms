<template>
  <div id="Foot">
    <el-footer></el-footer>
  </div>
</template>
<script>
export default {
  name: "Foot"
};
</script>

<style>


</style>