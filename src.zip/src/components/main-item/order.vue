<template>
  <div id="Order">
      我是订单管理
  </div>
</template>
<script>
export default {
  name: "Order"

};
</script>

<style>


</style>