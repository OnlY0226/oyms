<template>
  <div id="UserManager">
    我是用户管理
    
  </div>
</template>
<script>

export default {
  name: "UserManager"
};
</script>

<style>


</style>