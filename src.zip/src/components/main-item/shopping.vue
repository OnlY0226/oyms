<template>
  <div id="shopping">
      <ShoppingContent></ShoppingContent>
  </div>
</template>
<script>
import ShoppingContent from "./shopping-item/shopping-content"
export default {
  name: "Shopping",
  components:{
    ShoppingContent
  }
};
</script>
<style>


</style>