<template>
  <div id="authManage">
      <AuthManageContent></AuthManageContent>
  </div>
</template>
<script>
import AuthManageContent from "./authManage-item/authManage-content"
export default {
  name: "AuthManage",
  components:{
    AuthManageContent
  }
};
</script>
<style>


</style>